# Security and privacy

SupportBridge telemetry may contain customer context. Integrators are responsible for choosing what they collect and for meeting their own disclosure, consent, retention, and regulatory obligations.

## Safe defaults

- Prompt and model-response capture is disabled by default.
- Common credential fields and bearer tokens are redacted before queueing.
- Strings, arrays, object keys, and nesting depth are bounded.
- Telemetry delivery is fail-open and never intentionally exposes the configured API key in an event.
- The SDK has no runtime dependencies.

Redaction is defense in depth, not a substitute for minimizing data at the integration boundary. Do not pass credentials or regulated data in tool arguments when it is avoidable. Add product-specific field names to `privacy.sensitiveKeys`.

## Deployment recommendations

- Send telemetry only to a TLS endpoint you control or trust.
- Load the SupportBridge API key from a secret manager and rotate it regularly.
- Use a durable `TriggerStateStore` in multi-instance deployments.
- Apply least-privilege access and retention controls to the telemetry backend.
- Review custom result summarizers; they run before the SDK sanitizer.
- Call `close()` during graceful shutdown to flush queued events.

## Reporting a vulnerability

Do not include secrets, customer data, or exploit details in a public issue. Contact the package maintainer through the private security channel configured for the SupportBridge project. A public reporting address will be added before registry publication.
