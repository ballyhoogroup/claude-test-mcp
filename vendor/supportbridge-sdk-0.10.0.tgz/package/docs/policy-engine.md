# Policy engine

SupportBridge policies have one executable form: `CanonicalPolicy` schema version `1.0`. Both the natural-language and manual authoring experiences operate on that object. The original prompt is audit context, never executable input.

## Safety boundary

- Only paths in `PolicyRegistry.fields` can be read.
- Each field declares its value type and allowed operators.
- Only actions in `PolicyRegistry.actions` can enter a decision plan.
- Action parameters are typed and reference parameters can be checked by a `PolicyReferenceResolver`.
- Unknown paths, operators, events, actions, parameters, unsafe patterns, and cross-workspace references fail validation.
- Evaluation receives an explicit clock, has bounded condition depth and action counts, and prevents a policy from reprocessing an event it emitted.
- Simulations call the pure evaluator and never call an action executor.

## Authoring pipeline

`PolicyNlpProvider` is vendor-neutral. Its `compile` method returns a canonical draft, assumptions, ambiguities, unsupported requests, confidence, and an explanation. `FakePolicyNlpProvider` is deterministic and intended for local development and automated tests. A production LLM provider must use schema-constrained output and still pass the result through `validatePolicy`.

The MCP installation registers `open_policy_builder`, `generate_policy_draft`, `validate_policy_draft`, and `simulate_policy_draft`, plus `ui://supportbridge/policy-builder.html`. The embedded app visibly supports “Describe with AI” and “Build manually.” The draft stays in one canonical object while the administrator switches modes.

## Evaluation and execution

`PolicyEngine.evaluate` sorts by priority, category, then stable policy ID. It returns condition traces, proposed or dry-run-suppressed actions, missing fields, conflicts, and deterministic deduplication keys. It does not perform side effects.

Use `executeDecisionPlan` only after authorization. Supply a persistent `IdempotencyStore` in distributed production systems; `MemoryIdempotencyStore` is for local or single-process use.

## Governance

`MemoryPolicyStore` demonstrates the lifecycle contract:

1. Create and update a revision-checked draft.
2. Validate and request approval.
3. Require another authorized actor to approve.
4. Publish an immutable version, initially in dry-run mode by default.
5. Disable or roll back by appending a new version.
6. Retain workspace-scoped audit events and version diffs.

Production control planes should implement the same contract with durable transactions, tenant authorization, encrypted storage, rate limits, and an append-only audit log.

## Production extension points

- Add approved domain fields and resolvers through `PolicyRegistry`.
- Add typed actions and tenant reference kinds through action definitions.
- Implement `PolicyReferenceResolver` against the active tenant catalog.
- Implement `PolicyNlpProvider` for the chosen model vendor.
- Implement durable policy, evaluation-log, action-execution, and idempotency repositories.
- Send policy evaluation metrics and redacted traces through the existing telemetry transport.
