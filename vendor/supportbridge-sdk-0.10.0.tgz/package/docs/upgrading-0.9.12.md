# Upgrading to SDK 0.9.12

Install the exact release, rebuild your MCP, and restart its server/host connection:

```sh
npm install @supportbridge/sdk@0.9.12 --save-exact
```

## Chat identity requirement

`SupportBridge.install(server, { identify, ... })` now uses the existing `identify(context)` callback for every chat operation, including widget polling and messages. Return the same authenticated user ID and optional workspace scope used when creating the support ticket. Resolve identity from trusted server authentication context, not tool arguments or model-generated values. Do not use one shared identity for multiple people.

For lower-level integrations:

- Pass `{ identify }` to `createSupportChatApp(controlPlane, options)` and forward the request context to its handlers.
- Pass identity to `controlPlane.getChat(ticketId, identity)`, `endChat(ticketId, identity)`, and `reopenChat(ticketId, identity)`.
- Use `controlPlane.sendUserMessage(ticketId, text, senderName, identity)` for direct message calls.

The hardened control plane requires matching MCP connection credentials, user ID, and workspace scope. Missing or mismatched identity returns 404. Older SDKs without identity forwarding cannot read, message, end, or reopen chats on that server.

## Rollout order

1. Publish the SDK without deploying the hardened dashboard yet.
2. Upgrade and restart each customer/test MCP. Check discovery, a fresh offer, explicit acceptance, widget polling, messages, and ending a conversation in the actual host. Test decline separately.
3. Privately check production bootstrap credentials and existing stored credentials. Deployment intentionally refuses known demo credentials; do not rotate stored credentials just by changing environment variables.
4. Deploy the control plane only after client compatibility and configuration checks pass. Keep existing data and a verified backup. Continue using a single control-plane writer.

SDK installation does not deploy the dashboard or change server settings. Optional-assistance modes remain controlled by server configuration. This release does not enable production Master Admin, public onboarding, or a multi-instance database architecture.
