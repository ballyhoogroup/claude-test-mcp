# Migrating to SDK 0.10.0

## Breaking default change

`SupportBridge.install(server, options)` now selects `toolProfile: "streamlined"`.
It registers exactly eight SupportBridge tools, independently of localhost versus
production. The authoritative list and visibility are exported by
`supportToolManifest()`; see the generated [README catalog](../README.md#tool-catalog-0100-migration).
Four are model-visible and four chat operations are app-only. A host picker may
display only the four model-visible tools; `tools/list` contains all eight.

To temporarily preserve the former default, explicitly opt in:

```ts
const support = SupportBridge.install(server, {
  ...options,
  toolProfile: "compatibility"
});
```

Compatibility registers the eight canonical tools plus four legacy aliases and
four policy-builder tools (16 total). With `policyApp: { enabled: false }` it
registers 12. `policyApp.enabled: true` in streamlined mode fails early: use
compatibility for policy-builder tools. Policy evaluation/synchronization still
works in the default mode. Low-level helper exports are retained; their
availability does not mean they are registered. Do not mix manual registration
helpers with the installer on one server.

## Upgrade and discovery

1. Deploy App2 0.9.17 (or a later compatible release) first so it knows the manifest for SDK 0.10.0.
   This is an additive connection-report field; no destructive database migration.
2. After this package is approved and published, install the exact SDK version,
   rebuild the MCP, and **restart with a fresh MCP server instance** when upgrading
   from 0.9.x. Those versions did not track registration handles, so their tools
   cannot safely be identified or deleted. Do not delete tools by name or prefix.
3. Remove environment-specific compatibility overrides in integration code if the
   new default is wanted. SDK upgrades cannot override an explicit customer option.
4. Reconnect the MCP host (or start a new host conversation) to clear cached tool
   discovery and HTML resources. Custom UI URIs should also be versioned when the
   profile/template changes.
   Default chat and offer-card resources have distinct profile-specific URLs;
   a custom `app.resourceUri` applies only to the chat, not the offer card.
5. Check Integrations in App2: the connection should report SDK 0.10.0, profile
   streamlined, manifest 1, and the eight names. Missing, unknown-release,
   inconsistent, extra, missing or duplicate names produce a visible warning.
   This is a server report, not proof that a host has refreshed its cache.
6. Test the actual host's chat after explicit acceptance: open, read messages,
   send, end, and reopen. Consent, targeting and business tool behavior are unchanged.

## Same-server reinstalls from tracked installations

Run the first installation before `server.connect(transport)`, as shown in the
example. MCP cannot add a new resource capability after negotiation; attempting a
first install on an already connected, untracked server fails before registration.

From this release onward the SDK tracks every tool and resource handle returned
by public MCP registration APIs. Reinstalling on the **same server object** removes
only those registrations before creating the new manifest. SDK-owned ownership
state is shared across module copies within one JS realm. It never reads private
MCP fields, renames business tools or guesses ownership from a SupportBridge-looking
name. An unowned collision fails and rolls back partial SDK registrations.

The previous installation's background work stops. Its retained business wrappers
still execute their original business handlers without SDK work; the installer
does not modify customer registration callbacks. For normal upgrades, rebuild and
restart the MCP so your business tools use the new installation's wrappers.

`await support.close()` stops policy synchronization (including its pending fetch),
removes process listeners, flushes/stops telemetry, and removes SDK-owned
registrations. It is idempotent; closing an older instance does not remove its
replacement. The customer still owns its server/transport and business tools.
If any adapter lacks working public `remove()` handles, reinstall fails before
new registrations are added. Close still stops background work but rejects with a
clear cleanup error; use a new server. Never silently accumulate registrations.

Connected public MCP APIs receive best-effort `notifications/tools/list_changed`
after changes. Disconnected or unsupported notification paths do not block cleanup;
hosts without dynamic discovery must reconnect.

## Manifest maintenance and release checks

`src/tool-manifest.ts` is the versioned source of truth. Names and visibility are
immutable at runtime. Installation verifies its exact registered set; telemetry,
README, App2's expected catalog and tests derive from this manifest. Increment the
manifest version when the catalog changes, retain release mappings, regenerate with
`node scripts/sync-tool-manifest.mjs`, and run `node scripts/verify-release.mjs`.
Add each SDK release to the release mapping even when its manifest is unchanged.
Keep prior definitions in `SUPPORT_TOOL_MANIFESTS` and prior release-to-version
values fixed, so App2 can still validate installed older releases.

`supportbridge doctor` checks connectivity, authentication, policies and ingestion.
It does **not** inspect a running MCP or overwrite its manifest/version report.
The packed-consumer test uses four customer business tools and asserts exactly
12 entries in real MCP `tools/list`, unchanged business definitions/results,
app-only metadata, declarations, cleanup and the packaged doctor command.

SDK and App2 now version independently. This SDK candidate is 0.10.0; App2 0.9.17
declares compatibility with SDK 0.9.14, 0.9.15, and 0.10.0. Follow
[the current staged release procedure](environments-and-releases.md), not the old
tag-triggered publication workflow. A successful staging candidate supplies the
immutable production image and SDK tarball. Promote that candidate, verify App2,
then run the separate npm publication workflow for the same candidate run.

Source preparation is not publication. After approval and infrastructure setup,
verify the deployed commit, npm tarball checksum, and external MCP tool discovery.
